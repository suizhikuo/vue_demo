﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;


//参考:http://www.cnblogs.com/zycblog/archive/2010/07/02/1769676.html
//http://www.cnblogs.com/stone_w/archive/2012/06/26/2563483.html
//http://blog.csdn.net/five824/article/details/7244546
//每次修改都要重新卸载,编译,安装,调试
//安装卸载命令要用 以管理员身份运行

namespace WindowsServiceDemo
{
    public partial class Service1 : ServiceBase
    {
        private Timer _timer;
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            _timer = new Timer { Interval = 1000 }; //每秒运行
            _timer.Elapsed += new ElapsedEventHandler(Run);
            _timer.AutoReset = true;
            _timer.Enabled = true;
        }

        private void Run(object source, ElapsedEventArgs e)
        {
            // 代码 
        }

        protected override void OnStop()
        {
        }
    }
}
