package com.alex.util;

import java.util.Map;

public class RSATest {
	public static void main(String[] args) throws Exception {
		String reqStr = "加密证书和RSA加密解密";
		//加密
		Map<String,String>  map = Decipher.encryptData(reqStr);
		
		//解密
		String respStr = Decipher.decryptData(map);
		System.out.println("解密后的数据为=============>" + respStr);
	}
}
