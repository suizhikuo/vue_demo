﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.A_Area
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(!PageValidate.IsNumber(txtAreaID.Text))
			{
				strErr+="AreaID格式错误！\\n";	
			}
			if(this.txtAreaName.Text.Trim().Length==0)
			{
				strErr+="AreaName不能为空！\\n";	
			}
			if(!PageValidate.IsNumber(txtSort.Text))
			{
				strErr+="Sort格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			int AreaID=int.Parse(this.txtAreaID.Text);
			string AreaName=this.txtAreaName.Text;
			int Sort=int.Parse(this.txtSort.Text);

			Maticsoft.Model.A_Area model=new Maticsoft.Model.A_Area();
			model.AreaID=AreaID;
			model.AreaName=AreaName;
			model.Sort=Sort;

			Maticsoft.BLL.A_Area bll=new Maticsoft.BLL.A_Area();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
