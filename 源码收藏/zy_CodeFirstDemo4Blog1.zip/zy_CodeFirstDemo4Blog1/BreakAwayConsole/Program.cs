﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.Entity;
//blog：oppoic.cnblogs.com

namespace BreakAwayConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //如果实体发生变化，就删除并重新生成数据库
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<CodeFirst.DataAccess.BreakAwayContext>());
            InsertDestination();
        }

        private static void InsertDestination()
        {
            var destination = new CodeFirst.Model.Destination
            {
                Country = "Indonesia",
                Description = "EcoTourism at its best in exquisite Bali",
                Name = "Bali"
            };
            using (var context = new CodeFirst.DataAccess.BreakAwayContext())
            {
                context.Destinations.Add(destination);
                context.SaveChanges();
            }
        }
    }
}
