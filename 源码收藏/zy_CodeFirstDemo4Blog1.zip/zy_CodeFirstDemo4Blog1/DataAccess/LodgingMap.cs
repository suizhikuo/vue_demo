﻿using System.Data.Entity.ModelConfiguration;

namespace CodeFirst.DataAccess
{
    public class LodgingMap : EntityTypeConfiguration<CodeFirst.Model.Lodging>
    {
        public LodgingMap()
        {
            Property(l => l.Name).IsRequired().HasMaxLength(200);   //不为空、长度200
        }
    }
}
