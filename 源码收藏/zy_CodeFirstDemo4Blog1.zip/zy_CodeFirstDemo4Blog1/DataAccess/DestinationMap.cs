﻿using System.Data.Entity.ModelConfiguration;

namespace CodeFirst.DataAccess
{
    public class DestinationMap : EntityTypeConfiguration<CodeFirst.Model.Destination>
    {
        public DestinationMap()
        {
            Property(d => d.Name).IsRequired();  //不为空
            Property(d => d.Description).HasMaxLength(500);  //长度的500
            Property(d => d.Photo).HasColumnName("image");    //设置Photo列的类型为image
        }
    }
}
