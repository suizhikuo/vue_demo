﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Infrastructure;
//blog：oppoic.cnblogs.com

namespace CodeFirst.DataAccess
{
    public class BreakAwayContext : DbContext
    {
        public BreakAwayContext()
            : base("name=BreakAwayContext")
        { }

        //以下是数据库上下文对象，以后对数据库的访问就用下面对象
        public DbSet<CodeFirst.Model.Destination> Destinations { get; set; }
        public DbSet<CodeFirst.Model.Lodging> Lodgings { get; set; }

        //用Fluent api必须重写OnModelCreating方法
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();//移除复数表名的契约
            //modelBuilder.Conventions.Remove<IncludeMetadataConvention>();//防止黑幕交易 要不然每次都要访问 
            //modelBuilder.Entity<CodeFirst.Model.Destination>().Property(d => d.Name).IsRequired();
            //modelBuilder.Entity<CodeFirst.Model.Destination>().Property(d => d.Description).HasMaxLength(500);
            //modelBuilder.Entity<CodeFirst.Model.Lodging>().Property(l => l.Name).IsRequired().HasMaxLength(200);

            //如上全部写OnModelCreating方法里太多了且不易维护，改进：
            modelBuilder.Configurations.Add(new DestinationMap());
            modelBuilder.Configurations.Add(new LodgingMap());
        }

        #region 一些常用的Data Annotations和Fluent API
        //【主键】
        //Data Annotations：
        //[Key]
        //public int DestinationId { get; set; }

        //Fluent API：
        //public class BreakAwayContext : DbContext
        //{
        //    protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //    {
        //        modelBuilder.Entity<Destination>().HasKey(d => d.DestinationId);
        //    }
        //}

        //【外键】
        //Data Annotations：
        //public int DestinationId { get; set; }
        //[ForeignKey("DestinationId")]
        //public Destination Destination { get; set; }

        //Fluent API：
        //modelBuilder.Entity<Lodging>().HasRequired(p => p.Destination).WithMany(p=>p.Lodgings).HasForeignKey(p => p.DestinationId);
        //【这只是简单的外键定义，后续还有一对一、一对多、多对多的详细配置】

        //【长度】
        //Data Annotations：通过StringLength(长度),MinLength(最小长度),MaxLength(最大长度)来设置数据库中字段的长度
        //[MinLength(10),MaxLength(30)]
        //public string Name { get; set; }
        //[StringLength(30)]
        //public string Country { get; set; }

        //Fluent API：没有设置最小长度这个方法
        //modelBuilder.Entity<Destination>().Property(p => p.Name).HasMaxLength(30);
        //modelBuilder.Entity<Destination>().Property(p => p.Country).HasMaxLength(30);

        //【非空】
        //Data Annotations：
        //public string Country { get; set; }
        //[Required(ErrorMessage="请输入描述")]
        //public string Description { get; set; }

        //Fluent API:
        //modelBuilder.Entity<Destination>().Property(p => p.Country).IsRequired();

        //【数据类型】
        //Data Annotations：
        //将string映射成ntext，默认为nvarchar(max)
        //[Column(TypeName = "ntext")]
        //public string Owner { get; set; }

        //Fluent API:
        //modelBuilder.Entity<Lodging>().Property(p => p.Owner).HasColumnType("ntext");

        //【表名】
        //Data Annotations：
        //[Table("MyLodging")]
        //public class Lodging
        //{
        //}

        //Fluent API
        //modelBuilder.Entity<Lodging>().ToTable("MyLodging");

        //【列名】
        //Data Annotations：
        //[Column("MyName")]
        //public string Name { get; set; }

        //Fluent API:
        //modelBuilder.Entity<Lodging>().Property(p => p.Name).HasColumnName("MyName");

        //【自增长】
        //Data Annotations
        //[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]  主键、自增长
        //public Guid SocialId { get; set; }

        //Fluent API:
        //modelBuilder.Entity<Person>().Property(p => p.SocialId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

        //【忽略列映射】
        //Data Annotations：
        //[NotMapped]
        //public string Name
        //{
        //    get
        //    {
        //        return FirstName + " " + LastName;
        //    }
        //}

        //Fluent API:NotMapped
        //modelBuilder.Entity<Person>().Ignore(p => p.Name);

        //【忽略表映射】
        //[NotMapped]
        //public class Person
        //{ }

        //Fluent API:
        //modelBuilder.Ignore<Person>();

        //【时间戳】
        //Data Annotations：Timestamp
        //[Timestamp]
        //public Byte[] TimeStamp { get; set; }   只能是byte类型

        //Fluent API:
        //modelBuilder.Entity<Lodging>().Property(p => p.TimeStamp).IsRowVersion();

        //【复杂类型】
        //Data Annotations
        // [ComplexType]
        // public class Address
        // {
        //     public string Country { get; set; }
        //     public string City { get; set; }
        // }

        //Fluent API:
        //modelBuilder.ComplexType<Address>();
        #endregion

    }
}
