﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.Model
{
    /// <summary>
    /// 人类
    /// </summary>
    public class Person
    {
        public int PersonId { get; set; }
        //[ConcurrencyCheck]
        public int SocialSecurityNumber { get; set; }   //社保号
        public string FirstName { get; set; }
        public string LastName { get; set; }

        //[Timestamp]
        //public byte[] RowVersion { get; set; }

        public Address address { get; set; }
    }
}
