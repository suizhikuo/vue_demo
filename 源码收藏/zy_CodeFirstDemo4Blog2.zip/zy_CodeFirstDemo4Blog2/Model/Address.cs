﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.Model
{
    /// <summary>
    /// 地址类（复杂类型）
    /// </summary>
    //[ComplexType]
    public class Address
    {
        //public int AddressId { get; set; }    //复杂类型不能有主键id（Key Property） 切记！
        public string StreetAddress { get; set; }  //街道地址
        public string City { get; set; }  //城市
        public string State { get; set; }  //州
        public string ZipCode { get; set; }  //邮编
    }
}
