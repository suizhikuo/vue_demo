﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.Model
{
    /// <summary>
    /// 旅行类
    /// </summary>
    public class Trip
    {
        //[Key]
        public Guid Identifier { get; set; }   //Guid类型，EF不会自动设主键
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal CostUSD { get; set; }

        //[Timestamp]
        public byte[] RowVersion { get; set; }
    }
}
