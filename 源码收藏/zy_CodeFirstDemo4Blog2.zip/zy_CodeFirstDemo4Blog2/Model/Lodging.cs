﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.Model
{
    /// <summary>
    /// 住宿类
    /// </summary>
    public class Lodging
    {
        public int LodgingId { get; set; }
        //[MinLength(1), MaxLength(30)]
        public string Name { get; set; }
        public string Owner { get; set; }
        public bool IsResort { get; set; }  //是否度假胜地

        public Destination Destination { get; set; }
    }
}
