﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.DataAccess
{
    public class TripMap : EntityTypeConfiguration<CodeFirst.Model.Trip>
    {
        public TripMap()
        {
            this.HasKey(t => t.Identifier); //主键
            this.Property(t => t.Identifier).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity); //Guid类型主键自增长
            this.Property(t => t.RowVersion).IsRowVersion();    //时间戳
        }
    }
}
