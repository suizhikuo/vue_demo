﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.DataAccess
{
    public class PersonMap : EntityTypeConfiguration<CodeFirst.Model.Person>
    {
        public PersonMap()
        {
            //this.HasKey(p => p.SocialSecurityNumber);  //主键
            this.Property(p => p.SocialSecurityNumber).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            //this.Property(p => p.RowVersion).IsRowVersion();  //时间戳
            this.Property(p => p.SocialSecurityNumber).IsConcurrencyToken();  //ConcurrencyCheck并发
        }
    }
}
