﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Infrastructure;
//blog：oppoic.cnblogs.com

namespace CodeFirst.DataAccess
{
    public class BreakAwayContext : DbContext
    {
        public BreakAwayContext()
            : base("name=BreakAwayContext")
        { }

        //以下是数据库上下文对象，以后对数据库的访问就用下面对象
        public DbSet<CodeFirst.Model.Destination> Destinations { get; set; }
        public DbSet<CodeFirst.Model.Lodging> Lodgings { get; set; }
        public DbSet<CodeFirst.Model.Trip> Trips { get; set; }
        public DbSet<CodeFirst.Model.Person> People { get; set; }

        //用Fluent api必须重写OnModelCreating方法
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();//移除复数表名的契约
            //modelBuilder.Conventions.Remove<IncludeMetadataConvention>();//防止黑幕交易 要不然每次都要访问 
            //modelBuilder.Entity<CodeFirst.Model.Destination>().Property(d => d.Name).IsRequired();
            //modelBuilder.Entity<CodeFirst.Model.Destination>().Property(d => d.Description).HasMaxLength(500);
            //modelBuilder.Entity<CodeFirst.Model.Lodging>().Property(l => l.Name).IsRequired().HasMaxLength(200);

            //如上全部写OnModelCreating方法里太多了且不易维护，改进：
            modelBuilder.Configurations.Add(new DestinationMap());
            modelBuilder.Configurations.Add(new LodgingMap());
            modelBuilder.Configurations.Add(new TripMap());
            modelBuilder.Configurations.Add(new PersonMap());
            modelBuilder.ComplexType<CodeFirst.Model.Address>();   //复杂类型
        }
    }
}
